export const DB_NAME = "Ticket-Management";
